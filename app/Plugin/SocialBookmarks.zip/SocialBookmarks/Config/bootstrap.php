<?php
/**
 * Hook helper
 */
    Croogo::hookHelper('Nodes', 'SocialBookmarks.SocialBookmarks');

?>
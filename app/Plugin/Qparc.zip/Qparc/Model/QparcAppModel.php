<?php

class QparcAppModel extends AppModel {

}

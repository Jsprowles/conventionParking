<?php

class LocationReservationOption extends QparcAppModel {

	public $name = 'LocationReservationOption';
	
	public $belongsTo = 'Location';

}

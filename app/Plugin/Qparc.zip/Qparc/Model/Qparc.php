<?php
class Qparc extends QparcAppModel{
	
	var $name = 'Qparc';

}
?>

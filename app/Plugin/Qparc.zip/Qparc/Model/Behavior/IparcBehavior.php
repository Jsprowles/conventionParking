<?php

class IparcBehavior extends ModelBehavior
{
	
}

<?php

$config = array(
	'EventHandlers' => array(
		'Qparc.QparcEventHandler' => array(
			'options' => array(
				'priority' => 1,
				),
			),
		),
	);

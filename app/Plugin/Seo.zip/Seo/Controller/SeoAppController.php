<?php
class SeoAppController extends AppController {

}
?>
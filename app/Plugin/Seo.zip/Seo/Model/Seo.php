<?php
class Seo extends SeoAppModel{
	var $name = 'Seo';
	
	var $belongsTo = array(
		'Node'
	);

}
?>

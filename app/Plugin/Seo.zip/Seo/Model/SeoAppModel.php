<?php
class SeoAppModel extends AppModel {

}
?>
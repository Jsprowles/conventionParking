<?php
class AmazonAppController extends AppController {
}


<?php
class AmazonAppModel extends AppModel {
	public $useTable = false;
}

